#!/usr/bin/bash

date
cal
pwd
ls
