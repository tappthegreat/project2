#!/usr/bin/bash

num_a=300
num_b=200

if [ $num_a -lt $num_b ]; then 
	echo "$num_a is less than $num_b!"
else
	echo "$num_a is greater than $num_b!"

fi

